export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyAxlnz9a-VIWAln1cqt23uLwQ935IwJaJM",
    authDomain: "estelar-shop.firebaseapp.com",
    databaseURL: "https://estelar-shop.firebaseio.com",
    projectId: "estelar-shop",
    storageBucket: "estelar-shop.appspot.com",
    messagingSenderId: "976213927761",
    appId: "1:976213927761:web:e6d2c18026e7aff2861570",
    measurementId: "G-QXS3DRK2CF"
}

